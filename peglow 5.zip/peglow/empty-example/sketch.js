var num = 50;

var x = [];

var y = [];

function setup() {

  createCanvas(800, 800);

  background(100)

  noStroke();

  for (var i = 0; i < num; i++) {

    x[i] = 0;

    y[i] = 0;

  }

}

function draw() {

  background(190, 100, 90, 1);

  // Copy array values from back to front

  for (var i = num-1; i > 0; i--) {

    x[i] = x[i-1];

    y[i] = y[i-1];
  }

  x[0] = mouseX; // Set the first element

  y[0] = mouseY; // Set the first element

  for (var i = 0; i < num; i++) {

    fill(i * 5);

    ellipse(x[i], y[i], 20, 20);

    triangle(200, 200, 300, 160, 300, 200);

    square(550, 200, 55);

    ellipse(450, 500, 55, 55);
  

    
  }
}























































































/*var x = 150;
var y = 450;
var w = 50;
var h = 50;

var a = 400;
var b = 35;
var c = 30;
var d = 30;


function setup() {
  createCanvas(800, 600);
  background (204);
  rect(x, y, w, h);
  ellipseMode(RADIUS);
  fill(255);
  ellipse(a, b, c, d);
  ellipseMode(CENTER);
  fill(100);
  ellipse(a, b, c, d);
  
}

function draw () {


  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(600, 450, 50, 50);
  describe('50-by-50 white rect that turns black on keypress.');
}

function mousePressed() {

  background (204);

  if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
    
    fill(0);

  }

  else {

    fill (255);

  }
  
  rect(x, y, w, h);
}

function mouseClicked() {

  if ((mouseX > a) && (mouseX < a+c) && (mouseY > b) && (mouseY < b+d)) {
    
    fill(0);

  }

  else {

    fill (255);

  }
  ellipse(a, b, c, d)

  square(243, 100, 325, 0, 0, 0, 0)
}*/


/*
// initial color for Ellipse
let R = 90;
let G = 0;
let B = 20;
let T = 1;
// initial color for Rect
let RectR = 70;
let RectG = 0;
let RectB = 20;
let RectT = 1;

// initial position for small ellipse

let posX = 0;

function setup(){

createCanvas(800, 800);
strokeWeight(7);
colorMode(RGB, 255, 255, 255, 1);
frameRate(90);
}

function draw() {

// use background in draw to have realistic animations
  background(255, 255, 255, 1);
  fill(RectR, RectG, RectB, RectT);
  rect(50, 50, 100, 100);
  fill(R, G, B, T);
  ellipse(posX , 50, 10, 10);
  for (var i = 50; i < 60; i += 60) {
    line(i, 150, i + 100, 50);
  }

  for (var i = 150; i < 160; i += 60) {
    line(i, 150, i + -100, 50);
  }

  if(keyIsPressed === false){
    posX++;
    RectR = 70;
    RectG = 0;
    RectB = 40;
    RectT = 1;
  } else {
    RectR = 0;
    RectG = 100;
    RectB = 0;
    RectT = 1;
  }
  if(posX > width){
    posX = 0;
  }
}

function mouseClicked() {

// reset position o

  posX = 0;

}*/
