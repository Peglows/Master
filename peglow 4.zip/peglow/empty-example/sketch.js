function draw() {
  createCanvas(800, 600);
  background (10);
//drawRectMove(MouseX, MouseY);//

 let x = 10;
print('The value of x is ' + x);


rectMode(CENTER);
translate(width / 2, height / 2);
translate(p5.Vector.fromAngle(millis() / 1000, 40));
circle(30, 30, 20);

circle(50, 50, 20);
scale(0.5);
circle(50, 50, 20);

angleMode(DEGREES); // Change the mode to DEGREES
  let a = atan2(mouseY - height / 2, mouseX - width / 2);
  translate(width / 2, height / 2);
  push();
  rotate(a);
  rect(-20, -5, 40, 10); // Larger rectangle is rotating in degrees
  pop();
  angleMode(RADIANS); // Change the mode to RADIANS
  rotate(a); // variable a stays the same
  rect(-40, -5, 20, 10); // Smaller rectangle is rotating in radians
  describe(`40×10 rect in center rotates with mouse moves.
    20×10 rect moves faster.`);

translate(width / 2, height / 2);
rotate(PI / 2.0);
rect(-2, -2, 52, 52);




 }
  /*function drawRectMove(rectSizeX,rectSizeY) {
rectMode(CENTER);
translate(width * .75, height * .25);

rect(0, 0, rectSizeX, rectSizeY);*/
  





















































































/*var x = 150;
var y = 450;
var w = 50;
var h = 50;

var a = 400;
var b = 35;
var c = 30;
var d = 30;


function setup() {
  createCanvas(800, 600);
  background (204);
  rect(x, y, w, h);
  ellipseMode(RADIUS);
  fill(255);
  ellipse(a, b, c, d);
  ellipseMode(CENTER);
  fill(100);
  ellipse(a, b, c, d);
  
}

function draw () {


  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
  }
  rect(600, 450, 50, 50);
  describe('50-by-50 white rect that turns black on keypress.');
}

function mousePressed() {

  background (204);

  if ((mouseX > x) && (mouseX < x+w) && (mouseY > y) && (mouseY < y+h)) {
    
    fill(0);

  }

  else {

    fill (255);

  }
  
  rect(x, y, w, h);
}

function mouseClicked() {

  if ((mouseX > a) && (mouseX < a+c) && (mouseY > b) && (mouseY < b+d)) {
    
    fill(0);

  }

  else {

    fill (255);

  }
  ellipse(a, b, c, d)

  square(243, 100, 325, 0, 0, 0, 0)
}*/


/*
// initial color for Ellipse
let R = 90;
let G = 0;
let B = 20;
let T = 1;
// initial color for Rect
let RectR = 70;
let RectG = 0;
let RectB = 20;
let RectT = 1;

// initial position for small ellipse

let posX = 0;

function setup(){

createCanvas(800, 800);
strokeWeight(7);
colorMode(RGB, 255, 255, 255, 1);
frameRate(90);
}

function draw() {

// use background in draw to have realistic animations
  background(255, 255, 255, 1);
  fill(RectR, RectG, RectB, RectT);
  rect(50, 50, 100, 100);
  fill(R, G, B, T);
  ellipse(posX , 50, 10, 10);
  for (var i = 50; i < 60; i += 60) {
    line(i, 150, i + 100, 50);
  }

  for (var i = 150; i < 160; i += 60) {
    line(i, 150, i + -100, 50);
  }

  if(keyIsPressed === false){
    posX++;
    RectR = 70;
    RectG = 0;
    RectB = 40;
    RectT = 1;
  } else {
    RectR = 0;
    RectG = 100;
    RectB = 0;
    RectT = 1;
  }
  if(posX > width){
    posX = 0;
  }
}

function mouseClicked() {

// reset position o

  posX = 0;

}*/
